#include "gui.h"
#include <string>
#include <sstream>

static const int BOARD_LEFT = 40;
static const int BOARD_TOP  = 40;
static const int CELL       = 70;
static const int PIECE_R    = 22;

MalomGUI::MalomGUI(HWND h) : hwnd(h) {}

void MalomGUI::setMode(bool humanVsAi) {
    aiVsHuman = humanVsAi;
    newGame();
}

POINT MalomGUI::pointPos(int idx) const {
    static const int cx[24] = {0,3,6, 1,3,5, 2,3,4, 0,1,2, 4,5,6, 2,3,4, 1,3,5, 0,3,6};
    static const int cy[24] = {0,0,0, 1,1,1, 2,2,2, 3,3,3, 3,3,3, 4,4,4, 5,5,5, 6,6,6};
    POINT p;
    p.x = BOARD_LEFT + cx[idx] * CELL;
    p.y = BOARD_TOP  + cy[idx] * CELL;
    return p;
}

int MalomGUI::hitTest(int x, int y) const {
    for (int i = 0; i < 24; ++i) {
        POINT p = pointPos(i);
        int dx = x - p.x, dy = y - p.y;
        if (dx*dx + dy*dy <= (PIECE_R+6)*(PIECE_R+6)) return i;
    }
    return -1;
}

void MalomGUI::newGame() {
    game = MalomGame();
    selected = -1;
    aiThinking = false;
    awaitingRemoval = false;
    removableList.clear();
    pendingMove = Move{};
    InvalidateRect(hwnd, nullptr, TRUE);
}

void MalomGUI::paint(HDC hdc) {
    RECT rc; GetClientRect(hwnd, &rc);
    HBRUSH bg = CreateSolidBrush(RGB(240, 220, 180));
    FillRect(hdc, &rc, bg);
    DeleteObject(bg);

    drawBoard(hdc);
    drawPieces(hdc);
    drawStatus(hdc);
}

void MalomGUI::drawBoard(HDC hdc) {
    HPEN pen = CreatePen(PS_SOLID, 3, RGB(60,40,20));
    HGDIOBJ old = SelectObject(hdc, pen);

    auto rect3 = [&](int off) {
        int x1 = BOARD_LEFT + off * CELL;
        int y1 = BOARD_TOP  + off * CELL;
        int x2 = BOARD_LEFT + (6-off) * CELL;
        int y2 = BOARD_TOP  + (6-off) * CELL;
        MoveToEx(hdc, x1, y1, nullptr); LineTo(hdc, x2, y1);
        LineTo(hdc, x2, y2); LineTo(hdc, x1, y2); LineTo(hdc, x1, y1);
    };
    rect3(0); rect3(1); rect3(2);

    auto line = [&](int i, int j) {
        POINT a = pointPos(i), b = pointPos(j);
        MoveToEx(hdc, a.x, a.y, nullptr); LineTo(hdc, b.x, b.y);
    };
    line(1, 4); line(4, 7);
    line(9,10); line(10,11); line(12,13); line(13,14);
    line(3,10); line(10,18); line(5,13); line(13,20);
    line(16,19); line(19,22); line(15,16); line(16,17);
    line(6,11); line(11,15); line(8,12); line(12,17);

    SelectObject(hdc, old);
    DeleteObject(pen);

    HBRUSH dot = CreateSolidBrush(RGB(60,40,20));
    for (int i = 0; i < 24; ++i) {
        POINT p = pointPos(i);
        Ellipse(hdc, p.x-4, p.y-4, p.x+4, p.y+4);
    }
    DeleteObject(dot);
}

void MalomGUI::drawPieces(HDC hdc) {
    for (int r : removableList) {
        POINT p = pointPos(r);
        HPEN pen = CreatePen(PS_SOLID, 4, RGB(220,30,30));
        HGDIOBJ op = SelectObject(hdc, pen);
        HBRUSH ob = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
        Ellipse(hdc, p.x-PIECE_R-5, p.y-PIECE_R-5, p.x+PIECE_R+5, p.y+PIECE_R+5);
        SelectObject(hdc, ob); SelectObject(hdc, op);
        DeleteObject(pen);
    }

    for (int i = 0; i < 24; ++i) {
        if (game.board[i] == Player::NONE) continue;
        POINT p = pointPos(i);
        COLORREF fill, edge;
        if (game.board[i] == Player::WHITE) { fill = RGB(250,250,250); edge = RGB(80,80,80); }
        else { fill = RGB(40,40,40); edge = RGB(0,0,0); }

        HBRUSH b = CreateSolidBrush(fill);
        HPEN pen = CreatePen(PS_SOLID, 2, edge);
        HGDIOBJ ob = SelectObject(hdc, b);
        HGDIOBJ op = SelectObject(hdc, pen);
        Ellipse(hdc, p.x-PIECE_R, p.y-PIECE_R, p.x+PIECE_R, p.y+PIECE_R);
        SelectObject(hdc, ob); SelectObject(hdc, op);
        DeleteObject(b); DeleteObject(pen);
    }
    if (selected >= 0 && selected < 24) {
        POINT p = pointPos(selected);
        HPEN pen = CreatePen(PS_SOLID, 3, RGB(220,30,30));
        HGDIOBJ op = SelectObject(hdc, pen);
        HBRUSH ob = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
        Ellipse(hdc, p.x-PIECE_R-4, p.y-PIECE_R-4, p.x+PIECE_R+4, p.y+PIECE_R+4);
        SelectObject(hdc, ob); SelectObject(hdc, op);
        DeleteObject(pen);
    }
}

void MalomGUI::drawStatus(HDC hdc) {
    SetBkMode(hdc, TRANSPARENT);

    SetTextColor(hdc, RGB(80,80,80));
    std::wstring modeStr = aiVsHuman ? L"Mód: gép ellen" : L"Mód: két ember";
    RECT modeRc; modeRc.left = 40; modeRc.top = 5; modeRc.right = 620; modeRc.bottom = 25;
    DrawTextW(hdc, modeStr.c_str(), -1, &modeRc, DT_LEFT | DT_NOPREFIX);

    SetTextColor(hdc, RGB(30,30,30));
    std::wstringstream ss;
    if (game.phase == GamePhase::GAME_OVER) {
        if (game.winner == Player::WHITE)      ss << L"Fehér nyert! Gratulálok!";
        else if (game.winner == Player::BLACK) ss << L"Fekete nyert. Próbáld újra!";
        else                                    ss << L"Játék vége.";
    } else if (awaitingRemoval) {
        ss << L"Malom! Kattints egy piros karikás ellenséges korongra a levételhez.";
    } else {
        ss << (game.currentPlayer == Player::WHITE ? L"Fehér" : L"Fekete") << L" lép.";
        switch (game.phase) {
            case GamePhase::PLACING: ss << L" (lerakás)"; break;
            case GamePhase::MOVING:  ss << L" (mozgatás)"; break;
            case GamePhase::FLYING:  ss << L" (ugrálás)"; break;
            default: break;
        }
        if (aiThinking) ss << L"  [AI gondolkodik...]";
    }
    ss << L"   Fehér: " << (game.piecesOnBoard[1] + game.piecesInHand[1])
       << L"  Fekete: " << (game.piecesOnBoard[2] + game.piecesInHand[2]);
    ss << L"   [N] = új játék";

    RECT textRc;
    textRc.left   = 40;
    textRc.top    = 540;
    textRc.right  = 620;
    textRc.bottom = 620;
    DrawTextW(hdc, ss.str().c_str(), -1, &textRc,
              DT_LEFT | DT_WORDBREAK | DT_NOPREFIX);
}

void MalomGUI::finalizeMove(const Move& m) {
    game.applyMove(m);
    selected = -1;
    awaitingRemoval = false;
    removableList.clear();
    pendingMove = Move{};
    InvalidateRect(hwnd, nullptr, TRUE);
    doAIMove();
}

void MalomGUI::beginRemoval(const Move& base) {
    pendingMove = base;
    removableList = game.removablePieces(
        (game.currentPlayer == Player::WHITE) ? Player::BLACK : Player::WHITE);
    awaitingRemoval = true;
    selected = -1;
    InvalidateRect(hwnd, nullptr, TRUE);
}

void MalomGUI::doAIMove() {
    if (!aiVsHuman) return;
    if (game.phase == GamePhase::GAME_OVER) return;
    if (game.currentPlayer != Player::BLACK) return;

    aiThinking = true;
    InvalidateRect(hwnd, nullptr, FALSE);
    UpdateWindow(hwnd);

    Move m = game.findBestMove(3);
    if (m.to >= 0) game.applyMove(m);

    aiThinking = false;
    selected = -1;
    awaitingRemoval = false;
    removableList.clear();
    InvalidateRect(hwnd, nullptr, TRUE);
}

void MalomGUI::onLButtonDown(int x, int y) {
    if (game.phase == GamePhase::GAME_OVER) return;
    if (aiVsHuman && game.currentPlayer == Player::BLACK) return;

    int idx = hitTest(x, y);
    if (idx < 0) { selected = -1; InvalidateRect(hwnd, nullptr, TRUE); return; }

    if (awaitingRemoval) {
        bool ok = false;
        for (int r : removableList) if (r == idx) { ok = true; break; }
        if (ok) {
            Move m = pendingMove;
            m.removeOpponent = true;
            m.removeIdx = idx;
            finalizeMove(m);
        }
        return;
    }

    if (game.phase == GamePhase::PLACING) {
        if (game.board[idx] != Player::NONE) return;
        auto moves = game.generateMoves();
        Move chosen; bool found = false;
        for (auto& m : moves) {
            if (m.from == -1 && m.to == idx) {
                chosen = m; found = true;
                if (m.removeOpponent) break;
            }
        }
        if (!found) return;
        if (chosen.removeOpponent) {
            Move base; base.from = -1; base.to = idx;
            beginRemoval(base);
        } else {
            finalizeMove(chosen);
        }
        return;
    }

    if (game.board[idx] == game.currentPlayer) {
        selected = idx;
        InvalidateRect(hwnd, nullptr, TRUE);
        return;
    }
    if (selected >= 0) {
        auto moves = game.generateMoves();
        Move chosen; bool found = false;
        for (auto& m : moves) {
            if (m.from == selected && m.to == idx) {
                chosen = m; found = true;
                if (m.removeOpponent) break;
            }
        }
        if (found) {
            if (chosen.removeOpponent) {
                Move base; base.from = selected; base.to = idx;
                beginRemoval(base);
            } else {
                finalizeMove(chosen);
            }
        } else {
            selected = -1;
            InvalidateRect(hwnd, nullptr, TRUE);
        }
    }
}