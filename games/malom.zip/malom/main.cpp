#include <windows.h>
#include "gui.h"

static MalomGUI* g_gui = nullptr;
static HICON g_appIcon = nullptr;

static HICON createMillIcon(int size) {
    HDC hdcScreen = GetDC(nullptr);
    HDC hdc = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmp = CreateCompatibleBitmap(hdcScreen, size, size);
    HBITMAP hOld = (HBITMAP)SelectObject(hdc, hbmp);

    RECT rc = { 0, 0, size, size };
    HBRUSH bg = CreateSolidBrush(RGB(240, 220, 180));
    FillRect(hdc, &rc, bg);
    DeleteObject(bg);

    HPEN pen = CreatePen(PS_SOLID, (size >= 32 ? 2 : 1), RGB(60, 40, 20));
    HPEN oldPen = (HPEN)SelectObject(hdc, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));

    int m = size / 8;
    for (int k = 0; k < 3; ++k) {
        int off = m * k;
        Rectangle(hdc, off, off, size - off, size - off);
    }
    MoveToEx(hdc, size/2, 0, nullptr);      LineTo(hdc, size/2, m);
    MoveToEx(hdc, size/2, size-m, nullptr); LineTo(hdc, size/2, size);
    MoveToEx(hdc, 0, size/2, nullptr);      LineTo(hdc, m, size/2);
    MoveToEx(hdc, size-m, size/2, nullptr); LineTo(hdc, size, size/2);

    SelectObject(hdc, oldPen);
    SelectObject(hdc, oldBrush);
    DeleteObject(pen);

    HBRUSH white = CreateSolidBrush(RGB(250, 250, 250));
    HBRUSH black = CreateSolidBrush(RGB(40, 40, 40));
    HPEN edge = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
    HPEN oldPen2 = (HPEN)SelectObject(hdc, edge);

    int r = size / 10;
    auto drawPiece = [&](int cx, int cy, HBRUSH b) {
        HBRUSH ob = (HBRUSH)SelectObject(hdc, b);
        Ellipse(hdc, cx - r, cy - r, cx + r, cy + r);
        SelectObject(hdc, ob);
    };
    drawPiece(m, m, white);
    drawPiece(size - m, size - m, white);
    drawPiece(size/2, m, black);
    drawPiece(m, size/2, black);

    SelectObject(hdc, oldPen2);
    DeleteObject(edge); DeleteObject(white); DeleteObject(black);

    HBITMAP hMask = CreateBitmap(size, size, 1, 1, nullptr);
    HDC hMaskDC = CreateCompatibleDC(hdcScreen);
    HBITMAP hOldMask = (HBITMAP)SelectObject(hMaskDC, hMask);
    HBRUSH bgMask = CreateSolidBrush(RGB(255, 255, 255));
    RECT rcM = { 0, 0, size, size };
    FillRect(hMaskDC, &rcM, bgMask);
    DeleteObject(bgMask);
    SelectObject(hMaskDC, hOldMask);
    DeleteDC(hMaskDC);

    ICONINFO ii = {};
    ii.fIcon    = TRUE;
    ii.hbmMask  = hMask;
    ii.hbmColor = hbmp;
    HICON icon = CreateIconIndirect(&ii);

    SelectObject(hdc, hOld);
    DeleteObject(hbmp);
    DeleteObject(hMask);
    DeleteDC(hdc);
    ReleaseDC(nullptr, hdcScreen);

    return icon;
}

static bool askMode(HWND owner) {
    int res = MessageBoxW(owner,
        L"Kivel szeretnél játszani?\n\n"
        L"  Igen  = Gép ellen (te fehér, AI fekete)\n"
        L"  Nem   = Két ember (fehér vs fekete)\n\n"
        L"(A játék közben N billentyűvel újraindítható.)",
        L"Malomjáték – mód választása",
        MB_YESNO | MB_ICONQUESTION);
    if (res == IDNO) return false;
    return true;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        g_gui = new MalomGUI(hwnd);
        bool vsAi = askMode(hwnd);
        g_gui->setMode(vsAi);
        if (g_appIcon) {
            SendMessage(hwnd, WM_SETICON, ICON_BIG,   (LPARAM)g_appIcon);
            SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)g_appIcon);
        }
        return 0;
    }

    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        if (g_gui) g_gui->paint(hdc);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_LBUTTONDOWN: {
        int x = LOWORD(lParam);
        int y = HIWORD(lParam);
        if (g_gui) g_gui->onLButtonDown(x, y);
        return 0;
    }

    case WM_KEYDOWN:
        if (wParam == 'N' && g_gui) {
            bool vsAi = askMode(hwnd);
            g_gui->setMode(vsAi);
        }
        return 0;

    case WM_GETMINMAXINFO: {
        MINMAXINFO* mmi = (MINMAXINFO*)lParam;
        mmi->ptMinTrackSize.x = 640;
        mmi->ptMinTrackSize.y = 660;
        mmi->ptMaxTrackSize.x = 640;
        mmi->ptMaxTrackSize.y = 660;
        return 0;
    }

    case WM_DESTROY:
        delete g_gui;
        g_gui = nullptr;
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
    g_appIcon = createMillIcon(32);

    const wchar_t CLASS_NAME[] = L"MalomWindow";

    WNDCLASSEXW wc = {};
    wc.cbSize        = sizeof(WNDCLASSEXW);
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hIcon         = g_appIcon;
    wc.hIconSm       = g_appIcon;

    if (!RegisterClassExW(&wc)) {
        MessageBoxW(nullptr, L"Nem sikerült regisztrálni az ablakosztályt!",
                    L"Hiba", MB_ICONERROR | MB_OK);
        return 1;
    }

    RECT rc = { 0, 0, 640, 660 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME, FALSE);

    HWND hwnd = CreateWindowExW(
        0, CLASS_NAME, L"Malomjáték",
        WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME,
        CW_USEDEFAULT, CW_USEDEFAULT,
        rc.right - rc.left, rc.bottom - rc.top,
        nullptr, nullptr, hInst, nullptr);

    if (!hwnd) {
        MessageBoxW(nullptr, L"Nem sikerült létrehozni az ablakot!",
                    L"Hiba", MB_ICONERROR | MB_OK);
        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}