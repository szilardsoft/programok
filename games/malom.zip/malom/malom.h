#pragma once
#include <array>
#include <vector>
#include <optional>

enum class Player { NONE = 0, WHITE = 1, BLACK = 2 };
enum class GamePhase { PLACING, MOVING, FLYING, GAME_OVER };

struct Move {
    int from = -1;
    int to = -1;
    bool removeOpponent = false;
    int removeIdx = -1;
};

class MalomGame {
public:
    MalomGame();

    std::array<Player, 24> board;
    int piecesOnBoard[3];
    int piecesInHand[3];
    Player currentPlayer;
    GamePhase phase;
    Player winner;

    std::vector<Move> generateMoves() const;
    bool applyMove(const Move& m);
    void undoMove(const Move& m, Player prevPlayer, GamePhase prevPhase);

    bool isMill(int pos, Player p) const;
    std::vector<int> getMillsOf(Player p) const;
    bool allInMills(Player p) const;
    bool hasLegalMove(Player p) const;
    std::vector<int> neighbors(int pos) const;
    void updatePhase();

    std::vector<int> removablePieces(Player opponent) const;

    Move findBestMove(int depth = 3);

private:
    static const std::array<std::array<int,4>,24> adj;
    static const std::array<std::array<int,3>,16> mills;
    int evaluate() const;
    int minimax(int depth, bool maximizing, Player aiPlayer, int alpha, int beta);
    void applyMoveInternal(const Move& m, Player& prevPlayer, GamePhase& prevPhase);
    void undoMoveInternal(const Move& m, Player prevPlayer, GamePhase prevPhase);
};