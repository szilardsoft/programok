#pragma once
#include <windows.h>
#include "malom.h"

class MalomGUI {
public:
    MalomGUI(HWND hwnd);
    void paint(HDC hdc);
    void onLButtonDown(int x, int y);
    void newGame();
    void setMode(bool humanVsAi);

private:
    HWND hwnd;
    MalomGame game;
    int selected = -1;
    bool aiThinking = false;
    bool aiVsHuman = true;

    bool awaitingRemoval = false;
    Move pendingMove;
    std::vector<int> removableList;

    POINT pointPos(int idx) const;
    int  hitTest(int x, int y) const;
    void drawBoard(HDC hdc);
    void drawPieces(HDC hdc);
    void drawStatus(HDC hdc);
    void doAIMove();
    void finalizeMove(const Move& m);
    void beginRemoval(const Move& base);
};