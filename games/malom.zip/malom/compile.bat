@echo off
setlocal
echo === Malom forditas ===

if not exist build mkdir build

cl /nologo /EHsc /std:c++17 /O2 /W3 /utf-8 /DUNICODE /D_UNICODE main.cpp gui.cpp malom.cpp /Fe:build\malom.exe /Fo:build\ user32.lib gdi32.lib

if errorlevel 1 (
    echo FORDITASI HIBA!
    pause
    exit /b 1
)

echo.
echo === Sikeres forditas: build\malom.exe ===
pause
endlocal