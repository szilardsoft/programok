#include "malom.h"
#include <algorithm>
#include <climits>
#include <cstdlib>

const std::array<std::array<int,4>,24> MalomGame::adj = {{
    {{ 1,  9, -1, -1}}, // 0
    {{ 0,  2,  4, -1}}, // 1
    {{ 1, 14, -1, -1}}, // 2
    {{ 4, 10, -1, -1}}, // 3
    {{ 1,  3,  5,  7}}, // 4
    {{ 4, 13, -1, -1}}, // 5
    {{ 7, 11, -1, -1}}, // 6
    {{ 4,  6,  8, -1}}, // 7
    {{ 7, 12, -1, -1}}, // 8
    {{ 0, 10, 21, -1}}, // 9
    {{ 3,  9, 11, 18}}, //10
    {{ 6, 10, 15, -1}}, //11
    {{ 8, 13, 17, -1}}, //12
    {{ 5, 12, 14, 20}}, //13
    {{ 2, 13, 23, -1}}, //14
    {{11, 16, -1, -1}}, //15
    {{15, 17, 19, -1}}, //16
    {{12, 16, -1, -1}}, //17
    {{10, 19, -1, -1}}, //18
    {{16, 18, 20, 22}}, //19
    {{13, 19, -1, -1}}, //20
    {{ 9, 22, -1, -1}}, //21
    {{19, 21, 23, -1}}, //22
    {{14, 22, -1, -1}}  //23
}};

const std::array<std::array<int,3>,16> MalomGame::mills = {{
    {{0,1,2}},   {{3,4,5}},   {{6,7,8}},   {{9,10,11}},
    {{12,13,14}},{{15,16,17}},{{18,19,20}},{{21,22,23}},
    {{0,9,21}},  {{3,10,18}}, {{6,11,15}}, {{1,4,7}},
    {{16,19,22}},{{8,12,17}}, {{5,13,20}}, {{2,14,23}}
}};

MalomGame::MalomGame() {
    board.fill(Player::NONE);
    piecesOnBoard[1] = piecesOnBoard[2] = 0;
    piecesInHand[1]  = piecesInHand[2]  = 9;
    currentPlayer = Player::WHITE;
    phase = GamePhase::PLACING;
    winner = Player::NONE;
}

std::vector<int> MalomGame::neighbors(int pos) const {
    std::vector<int> res;
    for (int n : adj[pos]) if (n >= 0) res.push_back(n);
    return res;
}

bool MalomGame::isMill(int pos, Player p) const {
    for (const auto& m : mills) {
        bool hasPos = false, allP = true;
        for (int i : m) {
            if (i == pos) hasPos = true;
            if (board[i] != p) allP = false;
        }
        if (hasPos && allP) return true;
    }
    return false;
}

std::vector<int> MalomGame::getMillsOf(Player p) const {
    std::vector<int> res;
    for (int i = 0; i < 16; ++i) {
        if (board[mills[i][0]]==p && board[mills[i][1]]==p && board[mills[i][2]]==p)
            res.push_back(i);
    }
    return res;
}

bool MalomGame::allInMills(Player p) const {
    for (int i = 0; i < 24; ++i)
        if (board[i] == p && !isMill(i, p)) return false;
    return true;
}

std::vector<int> MalomGame::removablePieces(Player opponent) const {
    std::vector<int> res;
    bool allMill = allInMills(opponent);
    for (int i = 0; i < 24; ++i) {
        if (board[i] == opponent) {
            if (allMill || !isMill(i, opponent))
                res.push_back(i);
        }
    }
    return res;
}

bool MalomGame::hasLegalMove(Player p) const {
    if (piecesOnBoard[(int)p] <= 0) return false;
    for (int i = 0; i < 24; ++i) {
        if (board[i] != p) continue;
        if (piecesOnBoard[(int)p] <= 3) return true;
        for (int n : neighbors(i))
            if (board[n] == Player::NONE) return true;
    }
    return false;
}

void MalomGame::updatePhase() {
    if (phase == GamePhase::GAME_OVER) return;

    if (phase == GamePhase::PLACING && piecesInHand[1] == 0 && piecesInHand[2] == 0)
        phase = GamePhase::MOVING;

    Player cur = currentPlayer;

    if (phase != GamePhase::PLACING) {
        if (piecesOnBoard[(int)cur] < 3) {
            winner = (cur == Player::WHITE) ? Player::BLACK : Player::WHITE;
            phase = GamePhase::GAME_OVER;
            return;
        }
        if (!hasLegalMove(cur)) {
            winner = (cur == Player::WHITE) ? Player::BLACK : Player::WHITE;
            phase = GamePhase::GAME_OVER;
            return;
        }
    }

    if (phase != GamePhase::PLACING) {
        if (piecesOnBoard[(int)cur] == 3)      phase = GamePhase::FLYING;
        else if (piecesOnBoard[(int)cur] > 3)  phase = GamePhase::MOVING;
    }
}

std::vector<Move> MalomGame::generateMoves() const {
    std::vector<Move> moves;
    if (phase == GamePhase::GAME_OVER) return moves;
    Player p = currentPlayer;
    Player opp = (p == Player::WHITE) ? Player::BLACK : Player::WHITE;

    auto makesMill = [&](int from, int to) -> bool {
        std::array<Player,24> tmp = board;
        if (from >= 0) tmp[from] = Player::NONE;
        tmp[to] = p;
        for (const auto& m : mills) {
            bool hasTo = false, allP = true;
            for (int i : m) {
                if (i == to) hasTo = true;
                if (tmp[i] != p) allP = false;
            }
            if (hasTo && allP) return true;
        }
        return false;
    };

    auto addMovesWithRemove = [&](int from, int to) {
        Move base; base.from = from; base.to = to;
        if (makesMill(from, to)) {
            auto rem = removablePieces(opp);
            if (rem.empty()) moves.push_back(base);
            else for (int r : rem) {
                Move mm = base;
                mm.removeOpponent = true;
                mm.removeIdx = r;
                moves.push_back(mm);
            }
        } else {
            moves.push_back(base);
        }
    };

    if (phase == GamePhase::PLACING) {
        if (piecesInHand[(int)p] > 0)
            for (int i = 0; i < 24; ++i)
                if (board[i] == Player::NONE) addMovesWithRemove(-1, i);
        return moves;
    }

    bool canFly = (piecesOnBoard[(int)p] <= 3);

    if (canFly) {
        for (int i = 0; i < 24; ++i) {
            if (board[i] != p) continue;
            for (int j = 0; j < 24; ++j)
                if (board[j] == Player::NONE) addMovesWithRemove(i, j);
        }
    } else {
        for (int i = 0; i < 24; ++i) {
            if (board[i] != p) continue;
            for (int n : neighbors(i))
                if (board[n] == Player::NONE) addMovesWithRemove(i, n);
        }
    }
    return moves;
}

bool MalomGame::applyMove(const Move& m) {
    Player prev = currentPlayer;
    GamePhase prevPhase = phase;
    applyMoveInternal(m, prev, prevPhase);
    updatePhase();
    if (phase != GamePhase::GAME_OVER)
        currentPlayer = (currentPlayer == Player::WHITE) ? Player::BLACK : Player::WHITE;
    updatePhase();
    return true;
}

void MalomGame::applyMoveInternal(const Move& m, Player&, GamePhase&) {
    Player p = currentPlayer;
    Player opp = (p == Player::WHITE) ? Player::BLACK : Player::WHITE;

    if (m.from >= 0) {
        board[m.from] = Player::NONE;
    } else {
        piecesInHand[(int)p]--;
    }
    board[m.to] = p;
    piecesOnBoard[(int)p]++;

    if (m.removeOpponent && m.removeIdx >= 0) {
        board[m.removeIdx] = Player::NONE;
        piecesOnBoard[(int)opp]--;
    }
}

void MalomGame::undoMove(const Move& m, Player prevPlayer, GamePhase prevPhase) {
    undoMoveInternal(m, prevPlayer, prevPhase);
}

void MalomGame::undoMoveInternal(const Move& m, Player prevPlayer, GamePhase prevPhase) {
    Player p = prevPlayer;
    Player opp = (p == Player::WHITE) ? Player::BLACK : Player::WHITE;

    board[m.to] = Player::NONE;
    piecesOnBoard[(int)p]--;

    if (m.from >= 0) {
        board[m.from] = p;
    } else {
        piecesInHand[(int)p]++;
    }

    if (m.removeOpponent && m.removeIdx >= 0) {
        board[m.removeIdx] = opp;
        piecesOnBoard[(int)opp]++;
    }
    currentPlayer = prevPlayer;
    phase = prevPhase;
}

int MalomGame::evaluate() const {
    int score = 0;
    Player ai = Player::BLACK;
    Player hum = Player::WHITE;

    score += (piecesInHand[(int)ai]  - piecesInHand[(int)hum])  * 120;
    score += (piecesOnBoard[(int)ai] - piecesOnBoard[(int)hum]) * 100;
    score += ((int)getMillsOf(ai).size()  - (int)getMillsOf(hum).size()) * 50;

    int mobAI = 0, mobHum = 0;
    for (int i = 0; i < 24; ++i) {
        if (board[i] == ai) for (int n : neighbors(i)) if (board[n]==Player::NONE) mobAI++;
        if (board[i] == hum) for (int n : neighbors(i)) if (board[n]==Player::NONE) mobHum++;
    }
    score += (mobAI - mobHum) * 3;

    const int centerBonus[24] = {0,1,0, 1,3,1, 0,2,0, 1,3,2,2,3,1, 0,2,0, 1,3,1, 0,1,0};
    for (int i = 0; i < 24; ++i) {
        if (board[i] == ai) score += centerBonus[i];
        if (board[i] == hum) score -= centerBonus[i];
    }
    return score;
}

int MalomGame::minimax(int depth, bool maximizing, Player aiPlayer, int alpha, int beta) {
    if (phase == GamePhase::GAME_OVER || depth == 0) {
        if (phase == GamePhase::GAME_OVER) {
            if (winner == aiPlayer) return 100000 + depth * 100;
            if (winner == Player::NONE) return 0;
            return -100000 - depth * 100;
        }
        int e = evaluate();
        return maximizing ? e : -e;
    }

    auto moves = generateMoves();
    if (moves.empty()) return maximizing ? -99999 : 99999;

    if (maximizing) {
        int best = INT_MIN;
        for (auto& m : moves) {
            Player savedP = currentPlayer; GamePhase savedPh = phase;
            applyMoveInternal(m, savedP, savedPh);
            updatePhase();
            if (phase != GamePhase::GAME_OVER)
                currentPlayer = (currentPlayer==Player::WHITE)?Player::BLACK:Player::WHITE;
            updatePhase();

            int val = minimax(depth-1, false, aiPlayer, alpha, beta);

            currentPlayer = savedP; phase = savedPh;
            undoMoveInternal(m, savedP, savedPh);

            best = (std::max)(best, val);
            alpha = (std::max)(alpha, best);
            if (beta <= alpha) break;
        }
        return best;
    } else {
        int best = INT_MAX;
        for (auto& m : moves) {
            Player savedP = currentPlayer; GamePhase savedPh = phase;
            applyMoveInternal(m, savedP, savedPh);
            updatePhase();
            if (phase != GamePhase::GAME_OVER)
                currentPlayer = (currentPlayer==Player::WHITE)?Player::BLACK:Player::WHITE;
            updatePhase();

            int val = minimax(depth-1, true, aiPlayer, alpha, beta);

            currentPlayer = savedP; phase = savedPh;
            undoMoveInternal(m, savedP, savedPh);

            best = (std::min)(best, val);
            beta = (std::min)(beta, best);
            if (beta <= alpha) break;
        }
        return best;
    }
}

Move MalomGame::findBestMove(int depth) {
    auto moves = generateMoves();
    if (moves.empty()) return Move{};
    Player aiPlayer = currentPlayer;
    Move bestMove = moves[0];
    int bestVal = INT_MIN;

    for (auto& m : moves) {
        Player savedP = currentPlayer; GamePhase savedPh = phase;
        applyMoveInternal(m, savedP, savedPh);
        updatePhase();
        if (phase != GamePhase::GAME_OVER)
            currentPlayer = (currentPlayer==Player::WHITE)?Player::BLACK:Player::WHITE;
        updatePhase();

        int val = minimax(depth-1, false, aiPlayer, INT_MIN, INT_MAX);

        currentPlayer = savedP; phase = savedPh;
        undoMoveInternal(m, savedP, savedPh);

        if (val > bestVal) { bestVal = val; bestMove = m; }
    }
    return bestMove;
}